#ifndef UTILS_H
#define UTILS_H

#include "room.h"

void menu(ruangan room);

#endif